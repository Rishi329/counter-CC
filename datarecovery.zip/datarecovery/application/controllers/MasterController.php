<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MasterController extends CI_Controller {



    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        
        // Load form helper library
        $this->load->helper('form');
        // Load form validation library
        $this->load->library('form_validation');

        
        $this->load->model('MasterModel');
        // Load database
        $this->method_call =& get_instance();
		$this->load->library('session');
    }

    public function home(){
        $this->load->view('datarecovery/index');
    }

    public function memory_card(){
        $this->load->view('datarecovery/memory_card');
    }

    public function hard_drive(){
        $this->load->view('datarecovery/hard_drive');
    }

    public function mobile_devices(){
        $this->load->view('datarecovery/mobile_devices');
    }

    public function server_data(){
        $this->load->view('datarecovery/server_data');
    }

    public function tape(){
        $this->load->view('datarecovery/tape');
    }

    public function ssd(){
        $this->load->view('datarecovery/ssd_dataloss');
    }

    public function desktop_laptop(){
        $this->load->view('datarecovery/desk_lap');
    }

    public function flash_drive(){
        $this->load->view('datarecovery/flashdrive');
    }

    public function virtual_machine(){
        $this->load->view('datarecovery/virtual_machine');
    }

    public function raid(){
        $this->load->view('datarecovery/raid');
    }

    public function file_repair(){
        $this->load->view('datarecovery/file_repair');
    }

    public function disk_repair(){
        $this->load->view('datarecovery/disk_repair');
  }
  
  public function virtual_repair(){
    $this->load->view('datarecovery/virtual_repair');
}

public function database_repair(){
    $this->load->view('datarecovery/database_repair');
}

public function operating_sy_repair(){
    $this->load->view('datarecovery/operating_sy_repair');
}

public function email_repair(){
    $this->load->view('datarecovery/email_repair');
}

public function raid_repair(){
    $this->load->view('datarecovery/raid_repair');
}

public function physical_hdd(){
    $this->load->view('datarecovery/physical_hdd');  
}

public function mobiledevice_data(){
    $this->load->view('datarecovery/mobiledevice_data');  
}
public function data_wiping(){
    $this->load->view('datarecovery/data_wiping');  
}
public function datadestruction(){
    $this->load->view('datarecovery/datadestruction');  
}

public function about_us(){
    $this->load->view('about/about_us');  
}

}
?>
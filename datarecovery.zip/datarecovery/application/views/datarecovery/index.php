<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!--=============== REMIXICONS ===============-->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
        <link href="img/favicon.ico" rel="icon">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <!--=============== CSS ===============-->
        <link rel="stylesheet" href="<?php echo base_url(); ?>Plugins/css/navbar_footer.css">
        <link href="<?php echo base_url(); ?>Plugins/css/bootstrap.min.css" rel="stylesheet">

        <!--=============== Animation ===============-->
        <link href="<?php echo base_url(); ?>Plugins/css/animate.min.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>Plugins/css/timeline.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>Plugins/css/lead_form.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>Plugins/css/testimonial.css" rel="stylesheet">



        <title>DataRevoveryDoctor</title>
    </head>
    <body >

        <div class="container bg-white p-0 w-100">
            <!-- Navbar start -->
            <?php include(APPPATH.'views/datarecovery/navbar.php');?>
            <!-- Navbar end -->
    
    
            <div class="container hero-header" style="background-color: rgb(58, 102, 196); ">
                <div class="container px-lg-5">
                    <div class="row g-5 align-items-end">
                        <div class="col-lg-6 text-center text-lg-start">
                            <h1 class="text-white mb-3 animated slideInDown" style="font-size: 55px; font-weight: 700;">Data Recovery Doctor</h1>
                            <p class="text-white m-0 animated slideInDown" style="font-size: 20px;">Bring your data back to life</p>
                            <p class="text-white pb-3 animated slideInDown" style="font-size: 20px;">Your trusted Data Recovery Doctor.</p>
                            <ul class="hehh animated slideInLeft">
                                <li><i class="ri-star-line" style="margin: 0 0.4rem 0 0; color: #FFA765;"></i>Free Evaluation  in 30 minutes</li>
                                <li><i class="ri-star-line" style="margin: 0 0.4rem 0 0; color: #FFA765;"></i>Experienced Data Recovery Professionals</li>
                                <li><i class="ri-star-line" style="margin: 0 0.4rem 0 0; color: #FFA765;"></i>All Work completed in-Housespan</li>
                                <li><i class="ri-star-line" style="margin: 0 0.4rem 0 0; color: #FFA765;"></i>Your data is 100% secure at all times</li>
                                <li><i class="ri-star-line" style="margin: 0 0.4rem 0 0; color: #FFA765;"></i>Lab equiped with World Class Recovery Instruments</li>
                                <li><i class="ri-star-line" style="margin: 0 0.4rem 0 0; color: #FFA765;"></i>Certified Class-100 Clean Room Environment</li>
                                <li><i class="ri-star-line" style="margin: 0 0.4rem 0 0; color: #FFA765;"></i>Most Recoveries completed in 3-5 Business days</li>
                                <li><i class="ri-star-line" style="margin: 0 0.4rem 0 0; color: #FFA765;"></i>An ISO-27001:2013 & 9001:2015 Certified Company</li>
                            </ul>
                            
                        </div>
                        <div class="col-lg-6 text-center text-lg-start">
                                <img style="border: 7px solid white; border-top-left-radius: 8rem;" class="img-fluid animated zoomIn" src="<?php echo base_url(); ?>dist/img/home_hero.jpg" alt="">
                            
                        </div>
                    </div>
                </div>
            </div>


            <div class="container-xxl py-5">
                <div class="container px-lg-5">
                    <div class="row g-4">
                        <div class="col-lg-4 wow fadeInUp" data-wow-delay="0.1s">
                            <div class="feature-item bg-light rounded text-center p-4">
                                <img src="<?php echo base_url(); ?>dist/img/knife.jpg" alt="" style="width: 100px; border-radius: 50%; border: 4px solid rgb(94, 129, 202); margin: 1rem 0;">
                                <h5 class="mb-3">Class 100 Clean-Room Facility</h5>
                                <p class="m-0">A controlled environment that has a low level of environmental pollutants.</p>
                            </div>
                        </div>
                        <div class="col-lg-4 wow fadeInUp" data-wow-delay="0.3s">
                            <div class="feature-item bg-light rounded text-center p-4">
                                <img src="<?php echo base_url(); ?>dist/img/scope.jpg" alt="" style="width: 100px; border-radius: 50%; border: 4px solid rgb(94, 129, 202); margin: 1rem 0;">
                                <h5 class="mb-3">Expert Data Recovery</h5>
                                <p class="m-0">Our skilled technicians specialize in recovering data from damaged, corrupted, or failed hard drives.</p>
                            </div>
                        </div>
                        <div class="col-lg-4 wow fadeInUp" data-wow-delay="0.5s">
                            <div class="feature-item bg-light rounded text-center p-4">
                                <img src="<?php echo base_url(); ?>dist/img/security.jpg" alt="" style="width: 100px; border-radius: 50%; border: 4px solid rgb(94, 129, 202); margin: 1rem 0;">
                                <h5 class="mb-3">Data Security</h5>
                                <p class="m-0">100% privacy and confidentiality guarantee!</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



                <div class="page-section py-5" id="about">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-lg-6 py-3 wow animated fadeInUp" style="padding-left: 5rem;">
                                <span class="subhead">Welcome to</span>
                                <h2 class="title-section">Data Recovery Doctor</h2>
                                <div class="divider"></div>
                        
                                <p>At Data Recovery Doctor, we understand the critical importance of data in today's digital age. Whether it's precious memories captured in photographs, vital business documents, or sensitive financial information, the loss of data can be devastating. That's why our mission since day one has been to provide cutting-edge data recovery services to our clients, ensuring that their valuable information is never lost beyond retrieval.</p>
                                <p>Over the years, we have honed our expertise, invested in state-of-the-art technology, and assembled a team of highly skilled professionals dedicated to delivering unparalleled results. From accidental deletions to catastrophic hardware failures, we have the knowledge and tools to handle a wide range of data loss scenarios across various storage media and devices.</p>
                                <a href="about.html" class="btn btn-primary mt-3">Read More</a>
                            </div>
                            <div class="col-lg-6 py-3 wow fadeInRight">
                                <div class="img-fluid py-3 text-center">
                                    <img style="width: 100%;" src="<?php echo base_url()?>dist/img/hero-bg-2.jpg" alt="">
                                </div>
                            </div>
                        </div>
                    </div> <!-- .container -->
                </div>



              <div class="container-xxl py-5">
                <h2 style=" margin: 1rem 4rem;">Data Recovery Process</h2>
                <p style=" margin: 0rem 0rem 4rem 4rem; width: 60%;">Our data recovery process is straightforward and easy to understand. We are fully transparent in all steps of the process, so you can trust us to handle your data with care.</p>
                    <ul class="timeline">
                        <li style="--accent-color:#41516C;">
                            <div class="date">Initial Assessment</div>
                            <div class="title">The process begins with an initial assessment of the data loss situation. This may involve gathering information about the type of storage media, the cause of data loss, and any relevant details provided by the client.</div>
                        </li>
                        <li style="--accent-color:#FBCA3E;">
                            <div class="date">Quotation and Authorization</div>
                            <div class="title">EBased on the initial assessment, the data recovery provider issues a quotation for the recovery service. Once the client approves the quotation and provides authorization, the data recovery process can proceed.</div>
                        </li>
                        <li style="--accent-color:#E24A68;">
                            <div class="date">Media Evaluation</div>
                            <div class="title">The storage media (such as a hard drive, SSD, USB drive, etc.) is thoroughly evaluated to determine the extent of the damage and the feasibility of data recovery. This evaluation helps in understanding the nature of the problem and planning the appropriate recovery strategy.</div>
                        </li>
                        <li style="--accent-color:#1B5F8C;">
                            <div class="date">Physical Repair (if applicable)</div>
                            <div class="title">If the data loss is due to physical damage to the storage device, such as a malfunctioning drive mechanism or damaged circuitry, physical repairs may be necessary. Skilled technicians perform these repairs in a controlled environment, such as a clean room facility.</div>
                        </li>


                        <li style="--accent-color:#41516C;">
                            <div class="date">Logical Recovery</div>
                            <div class="title">Once any physical issues have been addressed, the data recovery process moves on to logical recovery techniques. This involves using specialized software tools and techniques to access, analyze, and recover data from the storage media.</div>
                        </li>
                        <li style="--accent-color:#FBCA3E;">
                            <div class="date">File Extraction and Reconstruction</div>
                            <div class="title">Data recovery specialists extract files and folders from the damaged storage media and reconstruct them into usable formats. This may involve repairing corrupted files, recovering deleted data, or piecing together fragmented data structures.</div>
                        </li>
                        <li style="--accent-color:#E24A68;">
                            <div class="date">Data Verification</div>
                            <div class="title">The recovered data undergoes thorough verification to ensure its integrity and completeness. Data integrity checks help identify any inconsistencies or errors in the recovered data, which may require further refinement.</div>
                        </li>
                        <li style="--accent-color:#1B5F8C;">
                            <div class="date">Data Transfer and Delivery</div>
                            <div class="title">Once the data has been successfully recovered and verified, it is transferred to a secure storage medium or delivered to the client according to their preferences. This may include options such as secure online delivery, physical media (such as USB drives or DVDs), or direct transfer to a replacement storage device.</div>
                        </li>
                        <li style="--accent-color:#41516C;">
                            <div class="date">Client Confirmation</div>
                            <div class="title">The client receives the recovered data and confirms its accuracy and completeness. They may also provide feedback on the recovery process and the quality of service received.</div>
                        </li>
                        <li style="--accent-color:#FBCA3E;">
                            <div class="date">Post-Recovery Support</div>
                            <div class="title">Data recovery providers often offer post-recovery support to assist clients with data restoration, data backup strategies, and any other related issues. This may include guidance on preventive measures to avoid future data loss incidents.</div>
                        </li>
                        
                    </ul>
                </div>
              </div>
    


              <div class="container-xxl fact py-5 wow fadeInUp" style="background-color: rgb(58, 102, 196);" data-wow-delay="0.1s">
                <div class="container py-5 px-lg-5">
                    <div class="row g-4">
                        <div class="col-md-6 col-lg-3 text-center wow fadeIn" data-wow-delay="0.1s">
                            <i class="fa fa-certificate fa-3x mb-3" style="color: #fd8a32;"></i>
                            <h1 class="text-white mb-2" data-toggle="counter-up">1234</h1>
                            <p class="text-white mb-0">Years Experience</p>
                        </div>
                        <div class="col-md-6 col-lg-3 text-center wow fadeIn" data-wow-delay="0.3s">
                            <i class="fa fa-users fa-3x mb-3" style="color: #fd8a32;"></i>
                            <h1 class="text-white mb-2" data-toggle="counter-up">1234</h1>
                            <p class="text-white mb-0">Team Members</p>
                        </div>
                        <div class="col-md-6 col-lg-3 text-center wow fadeIn" data-wow-delay="0.5s">
                            <i class="fa fa-user fa-3x mb-3" style="color: #fd8a32;"></i>
                            <h1 class="text-white mb-2" data-toggle="counter-up">1234</h1>
                            <p class="text-white mb-0">Satisfied Clients</p>
                        </div>
                        <div class="col-md-6 col-lg-3 text-center wow fadeIn" data-wow-delay="0.7s">
                            <i class="fa fa-check fa-3x mb-3" style="color: #fd8a32;"></i>
                            <h1 class="text-white mb-2" data-toggle="counter-up">1234</h1>
                            <p class="text-white mb-0">Compleate Projects</p>
                        </div>
                    </div>
                </div>
            </div>




            
                <div class="container-xxl py-5">
                    <!-- ***** Section Title Start ***** -->
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="center-heading">
                                <h2 class="section-title">Schedule a Pick-up</h2>
                            </div>
                        </div>
                        <div class="offset-lg-3 col-lg-6">
                            <div class="center-text">
                                <p>The service is free of charge, but only for hardware failure cases that have been pre-approved.</p>
                            </div>
                        </div>
                    </div>
                    <!-- ***** Section Title End ***** -->
        
                    <div class="row">
                        <!-- ***** Contact Text Start ***** -->
                        <div class="col-lg-4 col-md-6 col-sm-12">
                            <h5 class="margin-bottom-30">Disk Protective Box</h5>
                            <div class="contact-text">
                                <p>Built-in anti-vibration and anti-static cushioning mat for maximum HDD protection.</p>
                            </div>
                            <h5 class="margin-bottom-30">Save your time</h5>
                            <div class="contact-text">
                                <p>Built-in anti-vibration and anti-static cushioning mat for maximum HDD protection.</p>
                            </div>
                            <h5 class="margin-bottom-30">Convenience</h5>
                            <div class="contact-text">
                                <p>For those who don't own transportation or live far away.</p>
                            </div>
                        </div>
                        <!-- ***** Contact Text End ***** -->
        
                        <!-- ***** Contact Form Start ***** -->
                        <div class="col-lg-8 col-md-6 col-sm-12">
                            <div class="contact-form">
                                <form id="contact" action="" method="get">
                                  <div class="row">
                                    <div class="col-lg-6 col-md-12 col-sm-12">
                                      <fieldset>
                                        <input name="name" type="text" class="form-control" id="name" placeholder="Full Name" required="">
                                      </fieldset>
                                    </div>
                                    <div class="col-lg-6 col-md-12 col-sm-12">
                                      <fieldset>
                                        <input name="email" type="email" class="form-control" id="email" placeholder="E-Mail Address" required="">
                                      </fieldset>
                                    </div>
                                    <div class="col-lg-6 col-md-12 col-sm-12">
                                        <fieldset>
                                          <input name="selectdevice" type="text" class="form-control" id="name" placeholder="Select Device" required="">
                                        </fieldset>
                                      </div>
                                      <div class="col-lg-6 col-md-12 col-sm-12">
                                        <fieldset>
                                          <input name="problem" type="email" class="form-control" id="email" placeholder="Select Problem" required="">
                                        </fieldset>
                                      </div>
                                    <div class="col-lg-12">
                                      <fieldset>
                                        <textarea name="message" rows="6" class="form-control" id="message" placeholder="Address or describe the issue (Optional)" required=""></textarea>
                                      </fieldset>
                                    </div>
                                    <div class="col-lg-12">
                                      <fieldset>
                                        <button type="submit" id="form-submit" class="main-button">Send Message</button>
                                      </fieldset>
                                    </div>
                                  </div>
                                </form>
                            </div>
                        </div>
                        <!-- ***** Contact Form End ***** -->
                    </div>
                </div>




                <!-- Testimonial Section -->
                <div class="container" >
                    <hr>
                    <h2 class="title-section" style="text-align: center;">Reviews</h2>
                <div class="testimonial-container">
                    <div class="progress-bar" style="background-color: #4761d3; height: 4px; width: 100%; margin-bottom: 40px; animation: grow 10s linear infinite; transform-origin: left;"></div>
                    <div class="fas fa-quote-left fa-quote"></div>
                    <div class="fas fa-quote-right fa-quote"></div>
                    <p class="testimonial">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quia repellendus, vitae suscipit culpa molestiae possimus voluptate consequuntur odit nulla saepe obcaecati dolorem laudantium praesentium aspernatur mollitia aperiam laborum rem cum commodi doloremque asperiores officia hic similique. Sint ad nobis quos?</p>
                    <div class="user">
                        <img src="<?php echo base_url()?>dist/img/scope.jpg" alt="user" class="user-image">
                        <div class="user-details">
                        <h4 class="username">Lola Smith</h4>
                        <p class="role">Marketing</p>
                        </div>
                    </div>
                    </div>
                </div>


    </div>

 

    <!-- Footer Start -->
    <?php include(APPPATH.'views/datarecovery/footer.php');?>
    <!-- Footer end -->
        

        
        
        <!--=============== MAIN JS ===============-->
        <script src="<?php echo base_url()?>Plugins/js/testimonial.js"></script>
        
    </body>
</html>
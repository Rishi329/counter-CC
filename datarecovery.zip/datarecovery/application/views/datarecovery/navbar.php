<head>
    <link rel="stylesheet" href="<?php echo base_url(); ?>Plugins/css/navbar_footer.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>Plugins/css/bootstrap.min.css" >
    <link rel="stylesheet" href="<?php echo base_url(); ?>Plugins/css/animate.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>Plugins/css/animate.min.css" >
    <link rel="stylesheet" href="<?php echo base_url(); ?>Plugins/css/timeline.css">
</head>
<header class="header">
                <nav class="nav container1">
                    <div class="nav__data">
                        <a href="#" class="nav__logo">
                            <i class="ri-code-s-slash-line"></i>Data Recovery Doctor
                        </a>
        
                        <div class="nav__toggle" id="nav-toggle">
                            <i class="ri-menu-line nav__toggle-menu"></i>
                            <i class="ri-close-line nav__toggle-close"></i>
                        </div>
                    </div>
    
                    <!--=============== NAV MENU ===============-->
                    <div class="nav__menu" id="nav-menu">
                        <ul class="nav__list">
                            <li>
                                <a href="./home" class="nav__link">Home</a>
                            </li>
    
                            <!--=============== DROPDOWN 1 ===============-->
                            <li class="dropdown__item">                      
                                <div class="nav__link dropdown__button">
                                    Services <i class="ri-arrow-down-s-line dropdown__arrow"></i>
                                </div>
    
                                <div class="dropdown__container">
                                    <div class="dropdown__content">
                                        <div class="dropdown__group">
                                            <div class="dropdown__icon">
                                                <i class="ri-flashlight-line"></i>
                                            </div>
        
                                            <span class="dropdown__title">Data Recovery Services</span>
        
                                            <ul class="dropdown__list">
                                                <li>
                                                    <i class="ri-hard-drive-2-line" style="margin: 0 0.4rem 0 0;"></i><a href="./hard_drive" class="dropdown__link">Hard Drive Data Recovery</a>
                                                </li>
                                                <li>
                                                    <i class="ri-server-line"  style="margin: 0 0.4rem 0 0;"></i><a href="./server_data" class="dropdown__link">Server Data Recovery</a>
                                                </li>
                                                <li>
                                                    <i class="ri-window-2-line"  style="margin: 0 0.4rem 0 0;"></i><a href="./memory_card" class="dropdown__link">Memory Card Data Recovery</a>
                                                </li>
                                                <li>
                                                    <i class="ri-tape-line" style="margin: 0 0.4rem 0 0;"></i><a href="./tape" class="dropdown__link">Tape Data Recovery</a>
                                                </li>
                                                <li>
                                                    <i class="ri-macbook-line"  style="margin: 0 0.4rem 0 0;"></i><a href="./desktop_laptop" class="dropdown__link">Desktop and Laptop Data Recovery</a>
                                                </li>
                                                <li>
                                                    <i class="ri-window-2-line"  style="margin: 0 0.4rem 0 0;"></i><a href="./flash_drive" class="dropdown__link">Flash Drive Data Recovery</a>
                                                </li>



                                                <li>
                                                    <i class="ri-smartphone-line"  style="margin: 0 0.4rem 0 0;"></i><a href="./mobile_devices" class="dropdown__link">Mobile Devices Data Recovery</a>
                                                </li>
                                                <li>
                                                    <i class="ri-sim-card-2-line"  style="margin: 0 0.4rem 0 0;"></i><a href="./ssd" class="dropdown__link">SSD Data Recovery</a>
                                                </li>
                                                <li>
                                                    <i class="ri-slideshow-3-line"  style="margin: 0 0.4rem 0 0;"></i><a href="./virtual_machine" class="dropdown__link">Virtual Machine Data Recovery</a>
                                                </li>
                                                <li>
                                                    <i class="ri-database-2-line"  style="margin: 0 0.4rem 0 0;"></i><a href="./raid" class="dropdown__link">Raid Data Recovery</a>
                                                </li>
                                                
                                            </ul>
                                        </div>
        
                                        <div class="dropdown__group">
                                            <div class="dropdown__icon">
                                                <i class="ri-pie-chart-line"></i>
                                            </div>
        
                                            <span class="dropdown__title">Data Repair Services</span>
        
                                            <ul class="dropdown__list">
                                                <li>
                                                    <i class="ri-file-settings-line" style="margin: 0 0.4rem 0 0;"></i><a href="./file_repair" class="dropdown__link">File Repair Services</a>
                                                </li>
                                                <li>
                                                    <i class="ri-u-disk-line" style="margin: 0 0.4rem 0 0;"></i><a href="./disk_repair" class="dropdown__link">Disk Repair Services</a>
                                                </li>
                                                <li>
                                                    <i class="ri-database-line " style="margin: 0 0.4rem 0 0;"></i><a href="./database_repair" class="dropdown__link">Database Repair Services</a>
                                                </li>
                                                <li>
                                                    <i class="ri-windows-line" style="margin: 0 0.4rem 0 0;"></i><a href="./operating_sy_repair" class="dropdown__link">OS Repair Services</a>
                                                </li>
                                                <li>
                                                    <i class="ri-computer-line" style="margin: 0 0.4rem 0 0;"></i><a href="./virtual_machine" class="dropdown__link">Virtual Machine Repair Services</a>
                                                </li>
                                                <li>
                                                    <i class="ri-mail-settings-line" style="margin: 0 0.4rem 0 0;"></i><a href="./email_repair" class="dropdown__link">Email Repair Services</a>
                                                </li>
                                                <li>
                                                    <i class="ri-database-2-line"  style="margin: 0 0.4rem 0 0;"></i><a href="./raid_repair" class="dropdown__link">Raid Data Repair Services</a>
                                                </li>
                                            </ul>
                                        </div>
        
                                        <div class="dropdown__group">
                                            <div class="dropdown__icon">
                                                <i class="ri-database-2-line"></i>
                                            </div>
        
                                            <span class="dropdown__title">Data Sanitization services</span>
        
                                            <ul class="dropdown__list">
                                                <li>
                                                    <i class="ri-file-shred-line" style="margin: 0 0.4rem 0 0;"></i><a href="./physical_hdd" class="dropdown__link">Physical Destruction</a>
                                                </li>
                                                <li>
                                                    <i class="ri-pie-chart-box-line" style="margin: 0 0.4rem 0 0;"></i><a href="./data_wiping" class="dropdown__link">Data Whiping</a>
                                                </li>
                                                <li>
                                                    <i class="ri-profile-line" style="margin: 0 0.4rem 0 0;"></i><a href="./datadestruction" class="dropdown__link">Certified Data Destruction</a>
                                                </li>
                                                <li>
                                                    <i class="ri-smartphone-line" style="margin: 0 0.4rem 0 0;"></i></i><a href="./mobile_devices" class="dropdown__link">Mobile Device Data Sanitization</a>
                                                </li>
                                            </ul>
                                        </div>
        
                                        
                                    </div>
                                </div>
                            </li>
    
                            
    
                            <li>
                                <a href="#" class="nav__link">Pricing</a>
                            </li>
    
                            <!--=============== DROPDOWN 2 ===============-->
                            <li class="dropdown__item">                        
                                <div class="nav__link dropdown__button">
                                   Resources <i class="ri-arrow-down-s-line dropdown__arrow"></i>
                                </div>
    
                                <div class="dropdown__container">
                                    <div class="dropdown__content">
                                        <div class="dropdown__group">
                                            <div class="dropdown__icon">
                                                <i class="ri-community-line"></i>
                                            </div>
        
                                            <span class="dropdown__title">About us</span>
        
                                            <ul class="dropdown__list">
                                                <li>
                                                    <a href="./about_us" class="dropdown__link">About us</a>
                                                </li>
                                                <li>
                                                    <a href="#" class="dropdown__link">Support</a>
                                                </li>
                                                <li>
                                                    <a href="#" class="dropdown__link">Contact us</a>
                                                </li>
                                            </ul>
                                        </div>
        
                                        <div class="dropdown__group">
                                            <div class="dropdown__icon">
                                                <i class="ri-shield-line"></i>
                                            </div>
        
                                            <span class="dropdown__title">Safety and quality</span>
        
                                            <ul class="dropdown__list">
                                                <li>
                                                    <a href="#" class="dropdown__link">Cookie settings</a>
                                                </li>
                                                <li>
                                                    <a href="#" class="dropdown__link">Privacy Policy</a>
                                                </li>
                                                <li>
                                                    <a href="#" class="dropdown__link">Terms and Conditions</a>
                                                </li>
                                            </ul>
                                        </div>
    
    
    
                                        <div class="dropdown__group">
                                            <div class="dropdown__icon">
                                                <i class="ri-edit-line"></i>
                                            </div>
        
                                            <span class="dropdown__title">Blogs</span>
        
                                            <ul class="dropdown__list">
                                                <li>
                                                    <a href="#" class="dropdown__link">Blogs</a>
                                                </li>
                                                
                                            </ul>
                                        </div>
    
    
                                        <div class="dropdown__group">
                                            <div class="dropdown__icon">
                                                <i class="ri-questionnaire-line"></i>
                                            </div>
        
                                            <span class="dropdown__title">Frequently Asked Questions</span>
        
                                            <ul class="dropdown__list">
                                                <li>
                                                    <a href="#" class="dropdown__link">FAQ's</a>
                                                </li>
                                                <li>
                                                    <a href="#" class="dropdown__link">Partner's Program</a>
                                                </li>
                                            </ul>
                                        </div>
    
    
    
                                    </div>
                                </div>
                            </li>
                            
    
                            <li>
                                <div class="phone"><i class="fa fa-phone" style="margin: 0 0.4rem 0 0;"></i> 91+ 9503578579</div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </header>
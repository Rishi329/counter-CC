<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!--=============== REMIXICONS ===============-->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
        <link href="img/favicon.ico" rel="icon">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <!--=============== CSS ===============-->
        <link rel="stylesheet" href="<?php echo base_url(); ?>Plugins/css/navbar_footer.css">
        <link href="<?php echo base_url(); ?>Plugins/css/bootstrap.min.css" rel="stylesheet">

        <!--=============== Animation ===============-->
        <link href="<?php echo base_url(); ?>Plugins/css/animate.min.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>Plugins/css/lead_form.css"  rel="stylesheet">



        <title>DataRevoveryDoctor</title>
    </head>
    <body >

        <div class="container bg-white p-0 w-100">
            <!-- Navbar start -->
            <?php include(APPPATH.'views/datarecovery/navbar.php');?>
            <!-- Navbar end -->
    
            

            
            <div class="container hero-header" style="background-color: rgb(58, 102, 196)">
                <div class="container px-lg-5">
                    <div class="row g-5 align-items-end">
                        <div class="col-lg-7 text-center text-lg-start">
                            <h1 class="text-white mb-3 animated slideInDown" style="font-size: 55px; font-weight: 700;">Certified Data Destruction</h1>
                            <p class="text-white m-0 animated slideInDown" style="font-size: 20px;">Are you worried about sensitive data that needs to be securely destroyed? Data Recovery Doctor is here to help! Our expert team offers comprehensive Certified Data Destruction Services, ensuring your information is permanently and safely eliminated.</p>
                            <ul class="hehh animated slideInLeft">
                                <li><i class="ri-star-line" style="margin: 0 0.4rem 0 0; color: #FFA765;"></i>Free Analysis - Within 15-20 Minutes</li>
                                <li><i class="ri-star-line" style="margin: 0 0.4rem 0 0; color: #FFA765;"></i>No Data-No Charge Guaranteed Policy</li>
                                <li><i class="ri-star-line" style="margin: 0 0.4rem 0 0; color: #FFA765;"></i>100% Guaranteed Results*</li>
                                <li><i class="ri-star-line" style="margin: 0 0.4rem 0 0; color: #FFA765;"></i>24-48 Hours Turnaround Time</li>
                                <li><i class="ri-star-line" style="margin: 0 0.4rem 0 0; color: #FFA765;"></i>Assured Data Safety & Confidentiality</li>
                                <li><i class="ri-star-line" style="margin: 0 0.4rem 0 0; color: #FFA765;"></i>Class 100 Certified Clean-Room</li>
                                <li><i class="ri-star-line" style="margin: 0 0.4rem 0 0; color: #FFA765;"></i>ISO 9001:2015 Certified Company</li>
                            </ul>
                        </div>
                        <div class="col-lg-5 text-center text-lg-start">
                            <img class="img-fluid animated zoomIn" style="width: 100%;" src="<?php echo base_url()?>dist/img/Images/disk-storage.png" alt="">
                        </div>

                        
                    </div>
                </div>
            </div>


          
            <div class="container-xxl">
                <div class="row px-lg-5" >
                    
                   
                    <div class="col-lg-8 px-5">
                        <div class="py-2 px-3">
                            <h4 class="mb-4" style="font-size: 30px;">Certified Data Destruction</h4>
                            <p style="font-size: 18px;">Certified data destruction refers to the secure and permanent removal of sensitive or confidential data from storage devices to ensure that it cannot be accessed, recovered, or compromised by unauthorized individuals. This process is crucial for businesses and organizations to protect sensitive information, maintain compliance with data protection regulations, and mitigate the risk of data breaches.
                            <p style="font-size: 18px;"><span style="font-weight: bold;">Secure Data Erasure:    </span> Certified data destruction involves using specialized software tools or techniques to overwrite data on storage devices, such as hard disk drives (HDDs), solid-state drives (SSDs), magnetic tapes, or other media, to render it unrecoverable. This process ensures that sensitive data cannot be retrieved using standard data recovery methods.</p>
                            <p style="font-size: 18px;"><span style="font-weight: bold;">Compliance with Standards: </span>Certified data destruction adheres to industry standards and best practices for data sanitization, such as those outlined by organizations like the National Institute of Standards and Technology (NIST), the International Organization for Standardization (ISO), or regulatory requirements like the General Data Protection Regulation (GDPR) or the Health Insurance Portability and Accountability Act (HIPAA). Compliance ensures that data destruction processes meet established criteria for effectiveness and security.</p>
                            <p style="font-size: 18px;"><span style="font-weight: bold;">Chain of Custody Documentation: </span>Certified data destruction services maintain a documented chain of custody for storage devices throughout the destruction process. This documentation tracks the handling, transportation, and destruction of storage media to ensure accountability and transparency.</p>
                            <p style="font-size: 18px;"><span style="font-weight: bold;">Physical Destruction:  </span> In some cases, certified data destruction may involve physically destroying storage devices to prevent data recovery. This may include methods such as shredding, crushing, or degaussing (demagnetizing) storage media to render it irrecoverable.</p>
                            <p style="font-size: 18px;"><span style="font-weight: bold;">Certificate of Destruction: </span>After data destruction is complete, certified data destruction services provide a certificate of destruction to confirm that the data has been securely and permanently erased. This certificate serves as proof of compliance with data protection regulations and can be used for audit and regulatory purposes.</p>
                           
                            <h5 class="my-4" style="font-size: 22px;">Benefits of Certified Data Destruction:</h5>
                            <p style="font-size: 18px;"><span style="font-weight: bold;">Data Security:  </span> Certified data destruction helps organizations safeguard sensitive information and prevent unauthorized access to confidential data, reducing the risk of data breaches and identity theft.</p>
                            <p style="font-size: 18px;"><span style="font-weight: bold;">Compliance Assurance:   </span>By following established standards and regulations for data destruction, organizations can demonstrate compliance with legal and regulatory requirements, avoiding potential fines, penalties, or reputational damage.</p>
                            <p style="font-size: 18px;"><span style="font-weight: bold;">Risk Mitigation: </span>  Proper data destruction practices help mitigate the risk of data leakage, data loss, or unauthorized access to sensitive information, protecting the organization's reputation and preserving customer trust.</p>
                            <p style="font-size: 18px;"><span style="font-weight: bold;">Peace of Mind: </span>By outsourcing data destruction to certified service providers, organizations can have peace of mind knowing that their sensitive data is securely and irreversibly erased, allowing them to focus on their core business activities.</p>
                            <p style="font-size: 18px;"><span style="font-weight: bold;">Environmental Responsibility:  </span>Certified data destruction services often include environmentally responsible disposal or recycling of electronic waste (e-waste), minimizing the impact on the environment and promoting sustainable practices</p>

  <p style="font-size: 18px;">In conclusion, secure data erasure is a critical component of data security and compliance efforts for organizations. By securely erasing data from storage devices before disposal or repurposing, organizations can protect sensitive information, mitigate risks, and demonstrate a commitment to data privacy and security.</p>
                        </div>
                    </div>

                    <div class="col-lg-4 roudned">
                        <div class="py-3 px-3">
                            <h4 class="font" style="font-weight: 600;">Need Recovery Assistance?</h4>
                            <div class="border rounded d-flex align-items-center justify-content-center" style="background-color: #e9e9f1b2; padding: 1.5rem 0; width: 100%;">
                                <div>
                                    <form action="">
                                        <h6 style="font-size: 1rem; color: #4e4e57; margin-bottom: 1.5rem;">Connect with our Advisor Now!</h6>
                                        <div class="input-contain">
                                            <input style="font-size: 16px; width: 300px;" type="text" id="fname" name="fname" autocomplete="off" value="" aria-labelledby="placeholder-fname">
                                            <label class="placeholder-text" for="fname" id="placeholder-fname">
                                                <div class="text">First Name</div>
                                            </label>
                                        </div>

                                        <div class="input-contain">
                                            <input style="font-size: 16px; width: 300px;" type="text" id="fname" name="fname" autocomplete="off" value="" aria-labelledby="placeholder-fname">
                                            <label class="placeholder-text" for="fname" id="placeholder-fname">
                                                <div class="text">Mobile number</div>
                                            </label>
                                        </div>


                                        <div class="input-contain">
                                            <input style="font-size: 16px; width: 300px;" type="text" id="fname" name="fname" autocomplete="off" value="" aria-labelledby="placeholder-fname">
                                            <label class="placeholder-text" for="fname" id="placeholder-fname">
                                                <div class="text">State</div>
                                            </label>
                                        </div>


                                        <div class="input-contain">
                                            <input style="font-size: 16px; width: 300px;" type="text" id="fname" name="fname" autocomplete="off" value="" aria-labelledby="placeholder-fname">
                                            <label class="placeholder-text" for="fname" id="placeholder-fname">
                                                <div class="text">City</div>
                                            </label>
                                        </div>


                                        <button style="width: 100%; border-radius: 0.3rem; background-color: rgb(58, 102, 196); height: 2.5rem; color: white; border: none;">Submit</button>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <div class="py-3 px-3 my-4">
                            <img src="<?php echo base_url()?>dist/img/harddrive-col.jpg" alt="" style="width: 100%;" class="rounded">
                        </div>
                    </div>
                </div>
            </div>

 

    <!-- Footer Start -->
    <?php include(APPPATH.'views/datarecovery/footer.php');?>
    <!-- Footer end -->
        

        
        
        <!--=============== MAIN JS ===============-->
        <script src="assets/js/main.js"></script>
        <script src="assets/owlcarousel/owl.carousel.min.js"></script>
        
    </body>
</html>